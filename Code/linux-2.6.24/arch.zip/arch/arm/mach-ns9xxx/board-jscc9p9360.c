/*
 * arch/arm/mach-ns9xxx/board-jscc9p9360.c
 *
 * Copyright (C) 2006,2007 by Digi International Inc.
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as published by
 * the Free Software Foundation.
 */
#include "board-jscc9p9360.h"

void __init board_jscc9p9360_init_machine(void)
{
	/* TODO: reserve GPIOs for push buttons, etc pp */
}

