/*
 * arch/arm/mach-ns9xxx/board-jscc9p9360.h
 *
 * Copyright (C) 2006 by Digi International Inc.
 * All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as published by
 * the Free Software Foundation.
 */
#include <linux/init.h>

void __init board_jscc9p9360_init_machine(void);
