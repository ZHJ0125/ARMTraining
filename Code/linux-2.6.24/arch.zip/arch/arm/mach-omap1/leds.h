extern void innovator_leds_event(led_event_t evt);
extern void h2p2_dbg_leds_event(led_event_t evt);
extern void osk_leds_event(led_event_t evt);
