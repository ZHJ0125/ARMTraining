/*
 * arch/arm/mach-imx/leds.h
 *
 * Copyright (c) 2004 Sascha Hauer <sascha@saschahauer.de>
 *
 * blinky lights for IMX-based systems
 *
 */
extern void mx1ads_leds_event(led_event_t evt);
